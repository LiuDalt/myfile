package com.meiqia.meiqiasdk.model;

public class LeaveTipMessage extends BaseMessage {

    public LeaveTipMessage() {
        setItemViewType(TYPE_TIP);
    }

}