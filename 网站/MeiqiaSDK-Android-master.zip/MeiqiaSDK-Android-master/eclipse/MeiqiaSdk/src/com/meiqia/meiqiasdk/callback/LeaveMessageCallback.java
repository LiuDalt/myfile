package com.meiqia.meiqiasdk.callback;

/**
 * 作者:王浩 邮件:bingoogolapple@gmail.com
 * 创建时间:16/5/12 下午9:59
 * 描述:
 */
public interface LeaveMessageCallback {

    void onClickLeaveMessage();

}
