package com.meiqia.meiqiasdk.model;

public class NoAgentLeaveMessage extends BaseMessage {

    public NoAgentLeaveMessage() {
        setItemViewType(TYPE_NO_AGENT_TIP);
    }

}