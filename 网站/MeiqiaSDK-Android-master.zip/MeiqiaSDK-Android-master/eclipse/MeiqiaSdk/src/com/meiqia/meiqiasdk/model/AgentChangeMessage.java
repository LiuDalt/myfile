package com.meiqia.meiqiasdk.model;

public class AgentChangeMessage extends BaseMessage {

    public AgentChangeMessage() {
        setItemViewType(TYPE_TIP);
    }

}