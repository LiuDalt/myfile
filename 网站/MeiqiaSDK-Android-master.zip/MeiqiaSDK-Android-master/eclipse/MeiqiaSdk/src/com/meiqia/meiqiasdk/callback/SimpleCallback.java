package com.meiqia.meiqiasdk.callback;

/**
 * 作者:王浩 邮件:bingoogolapple@gmail.com
 * 创建时间:16/2/29 上午10:32
 * 描述:
 */
public interface SimpleCallback extends OnFailureCallBack {
    void onSuccess();
}
