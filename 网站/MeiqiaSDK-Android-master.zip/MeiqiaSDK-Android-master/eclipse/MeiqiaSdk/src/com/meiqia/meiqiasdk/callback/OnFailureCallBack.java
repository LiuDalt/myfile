package com.meiqia.meiqiasdk.callback;

public interface OnFailureCallBack {
    void onFailure(int code, String message);
}
