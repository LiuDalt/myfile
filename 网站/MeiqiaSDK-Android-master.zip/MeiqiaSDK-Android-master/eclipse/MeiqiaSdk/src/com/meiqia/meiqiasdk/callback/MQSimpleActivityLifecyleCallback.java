package com.meiqia.meiqiasdk.callback;

import android.os.Bundle;

import com.meiqia.meiqiasdk.activity.MQConversationActivity;

/**
 * OnePiece
 * Created by xukq on 7/13/16.
 */
public class MQSimpleActivityLifecyleCallback implements MQActivityLifecycleCallback {

    @Override
    public void onActivityCreated(MQConversationActivity activity, Bundle savedInstanceState) {

    }

    @Override
    public void onActivityStarted(MQConversationActivity activity) {

    }

    @Override
    public void onActivityResumed(MQConversationActivity activity) {

    }

    @Override
    public void onActivityPaused(MQConversationActivity activity) {

    }

    @Override
    public void onActivityStopped(MQConversationActivity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(MQConversationActivity activity, Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(MQConversationActivity activity) {

    }

}
